//
//  DNAdsRequestError.h
//  Demo
//
//  Created by Duc Nguyen on 9/14/13.
//  Copyright (c) 2013 DPigpen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DNAdsRequestError : NSObject

@end

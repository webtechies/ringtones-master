//
//  CrossPromotionLib.h
//  CrossPromotionLib
//
//  Created by Duc Nguyen on 9/2/13.
//  Copyright (c) 2013 DPigpen. All rights reserved.
//


// - tiêu đề và detail text khi loading trong khi remove ads setting screen
#define kTitleLoading @"Buying..."
#define kDetailTextLoading @"It takes some minutes for this action"


#define kTitleAlertLinkProversion @"Get the Premium version?"
#define kDetailAlertLinkProversion @"This is only the free version of our apps. Some functions are limited. To unlock all functions and remove ads, please get the Premium on the App Store"

#define kTitleAlertRemoveAds @"Remove Ads"
#define kDetailAlertRemoveAds @"This is only the free version of the apps. Do you want to upgrade to the premium version with unlimited usage and controllable ads showing ?"

#define kTitleShowAdsAgain @"Display Ads Confirm Mesage"
#define kDetailShowAdsAgain @"You have already removed ads before. Would you like to display ads again? You are still controllable turn off ads anywhere ?"

#define kTitleTurnOffAdsAgain @"Display Ads Confirm Mesage"
#define kDetailTurnOffAdsAgain @"You have already removed ads before. Would you like to turn off ads? You are still controllable turn on ads anywhere ?"